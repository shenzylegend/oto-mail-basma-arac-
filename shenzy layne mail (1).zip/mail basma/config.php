<?php
return [
    'host' => 'smtp.sunucu.com',
    'username' => 'kullanici@sunucu.com',
    'password' => 'sifre',
    'port' => 587,
    'encryption' => 'tls' // ssl veya tls
];
?>